<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ImageProfileController extends Controller
{
    //
}
