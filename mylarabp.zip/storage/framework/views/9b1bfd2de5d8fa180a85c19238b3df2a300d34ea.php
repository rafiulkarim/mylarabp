
<?php $__env->startSection('title', 'Update Role'); ?>
<?php $__env->startPush('css'); ?>
    <link rel="stylesheet"
        href="<?php echo e(asset('alte305/plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('plugins/select2/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <h3 class="fw-bold">Roles</h3>
    <ul class="breadcrumbs">
        <li class="nav-home">
            <a href="<?php echo e(url('/home')); ?>">
                <i class="fa fa-home"></i>
            </a>
        </li>
        <li class="separator">
            <i class="fas fa-angle-right"></i>
        </li>
        <li class="nav-item">
            <a href="<?php echo e(url('role')); ?>">Roles</a>
        </li>
        
    </ul>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('maincontent'); ?>
    <div class="row justify-content-center">
        <div class="col-md-7">
            <div class="card">
                <div class="card-header bg-primary">
                    <div class="card-title text-white" style="font-size: 13px">Update Role</div>
                </div>
                <form id="formSubmit">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" value="<?php echo e($role->id); ?>" name="id" id="role-id" >
                    <div class="card-body">
                        <div class="form-group">
                            <label for="email2">Role Title <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="title" name="title" required
                                value="<?php echo e($role->title); ?>" placeholder="Enter Title">
                            <small id="titleError" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label for="email2">Select Permissions <span class="text-danger">*</span></label>
                            <select class="form-select select2" id="permissions" name="permissions[]" multiple="multiple">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($permission->id); ?>"
                                        <?php echo e(in_array( $permission->id, $permissionData) ? 'selected' : ''); ?>

                                        ><?php echo e($permission->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <small id="permissionsError" class="form-text text-danger"></small>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <div class="d-flex">
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status" value="Active" id="active"
                                        <?php echo e($role->status == "Active" ? 'checked' : ''); ?>>
                                    <label class="form-check-label" for="active">
                                        Active
                                    </label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="status" value="Inactive"
                                    <?php echo e($role->status == "Inactive" ? 'checked' : ''); ?>

                                        id="inactive">
                                    <label class="form-check-label" for="inactive">
                                        Inactive
                                    </label>
                                </div>
                            </div>
                            <small id="statusError" class="form-text text-danger"></small>
                        </div>
                    </div>
                    <div class="card-action">
                        <button type="button" class="btn btn-outline-primary" onclick="window.history.back()"><i
                                class="fa fa-arrow-left"></i> Back</button>
                        <button type="submit" class="btn btn-primary float-end" id="saveButton">Submit <i
                                class="fa fa-save"></i>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script src="<?php echo asset('plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js'); ?>"></script>
    <script src="<?php echo asset('plugins/select2/js/select2.full.min.js'); ?>"></script>

    <script>
        $(function () {
            //Initialize Select2 Elements
            $('.select2').select2()
        })
    </script>
    <script>
        $(document).ready(function () {
            $("#formSubmit").validate({
                rules: {
                    title: {
                        required: true,
                    },
                    'permissions[]': {
                        required: true,
                    },
                    status: {
                        required: true
                    }
                },
                messages: {
                    title: "Please enter role title",
                    'permissions[]': "Please select at least one permission",
                    status: "Please select a status",
                },
                errorPlacement: function(error, element) {
                    // Custom error placement for specific fields
                    if (element.attr("name") == "title") {
                        error.appendTo("#titleError");
                    } else if (element.attr("name") == "permissions[]") {
                        error.appendTo("#permissionsError");
                    } else if (element.attr("name") == "status") {
                        error.appendTo("#statusError");
                    } else {
                        error.insertAfter(element);
                    }
                },
                submitHandler: function (form) {
                    var id = $('#role-id').val()
                    var data = $('#formSubmit').serialize();
                    console.log(data)
                    // console.log(id)
                    if ($("#formSubmit").valid()) {
                        $('#saveButton').prop("disabled", true);
                        //Calling Ajax
                        $.ajax({
                            type: "PUT",
                            data: data,
                            url: "<?php echo e(url('role/update')); ?>",
                            success: function (res) {
                                if (parseInt(res.success) == 1) {
                                    swal({
                                        title: "Success!",
                                        text: res.message,
                                        icon: "success",
                                        position: "top-end", // positions the alert at the top-right
                                        buttons: false, // hides buttons if you want it to be non-interactive
                                        timer: 3000, // auto close after 3 seconds
                                        customClass: {
                                            popup: 'swal2-custom-position'
                                        }
                                    });

                                    setTimeout(() => {
                                        window.location.href = "<?php echo e(url('/role')); ?>";
                                    }, 1000);
                                } else {
                                    $('#submit').prop("disabled", false);
                                }
                            }
                        });
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.al305_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Xampp\htdocs\mylarabp\resources\views/role/edit.blade.php ENDPATH**/ ?>